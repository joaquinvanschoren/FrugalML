package com.project.frugalmachinelearning.classifiers;

/**
 * Created by Mikhail on 02.05.2016.
 */
public enum ActivityType {
    WALKING,
    WALKING_UPSTAIRS,
    WALKING_DOWNSTAIRS,
    SITTING,
    STANDING,
    LAYING
}
