package com.project.frugalmachinelearning.tools;

/**
 * Created by Mikhail on 06.05.2016.
 */
public enum ApplicationStates {
    COLLECT_DATA,
    RECOGNIZE_ACTIVITY
}
